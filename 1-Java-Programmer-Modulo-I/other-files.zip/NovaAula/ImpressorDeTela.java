package br.com.cpaconsulting.interf;

public abstract class ImpressorDeTela {

    protected void imprimeNaTela(String valor) {
        System.out.println(valor);
    }
}
