import br.com.planetkiller.pacotes.teste.Empacotado;

public class SemPacote {
	public static void main(String[] args) {
		Empacotado emp = new Empacotado();
	}
}
