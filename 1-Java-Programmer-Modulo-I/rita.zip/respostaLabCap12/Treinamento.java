interface Treinamento{
	 static final String ESCOLA = "Impacta Tecnologia";
	 static final String FONE = "11 3285.5566";


	  double getPreco(int modulo);
}
