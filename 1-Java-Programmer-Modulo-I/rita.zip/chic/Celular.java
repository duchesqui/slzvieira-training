
	/**
	* Super classe para gerenciar todos os celulares do mercado
	* Escrevam bastante para documentar os seus projetos
	* isto ir� gerar um documento
	* em HTML para o usu�rio.
	* Ap�s compilar o arquivo, v� para o DOS e execute o seguinte comando:
	* javadoc Celular.java
	*/

public class Celular
{

	public boolean ligar()
	{
		return true;
	}

	/**
	* metodo para enviar mensagens
	* mais conhecidas como torpedos SMS
	* basta enviar a mensagem
	* e disparar o torpedo
	* @param: inserir um texto.
	*/

	public String enviaSMS(String mensagem)
	{
		return mensagem;
	}
}