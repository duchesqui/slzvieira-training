class Pessoa{
	
	char sexo;
	String nome;
	int idade;

// 	public String toString(){
// 		return( "sexo " + sexo + " - cabelo " + cabelo + " - idade " + idade);
// 	}
}