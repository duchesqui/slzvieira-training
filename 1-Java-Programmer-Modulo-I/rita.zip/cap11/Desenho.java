class Desenho
{
	void imprime()
	{
		System.out.println("figura nao especificada");
	}
}
