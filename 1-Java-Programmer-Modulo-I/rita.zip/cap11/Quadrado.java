class Quadrado extends Desenho
{
	void imprime()
	{
		System.out.println("imprimindo quadrado");
	}
}
