class Triangulo extends Desenho
{
	void imprime()
	{
		System.out.println("imprimindo triangulo");
	}
}
