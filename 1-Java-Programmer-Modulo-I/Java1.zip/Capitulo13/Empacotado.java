package br.com.planetkiller.pacotes.teste;

public class Empacotado {
}
