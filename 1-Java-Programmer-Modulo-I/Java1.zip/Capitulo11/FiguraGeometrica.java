public abstract class FiguraGeometrica {
	
	public abstract double getArea();
}
