package br.com.cpaconsulting.interf;

public interface Calculadora {

  public void exibeSoma(Integer valor1, Integer valor2);

  public void exibeSubtracao(Integer valor1, Integer valor2);

  public void exibeMultiplicacao(Integer valor1, Integer valor2);

  public void exibeDivisao(Integer valor1, Integer valor2);

}