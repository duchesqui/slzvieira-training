/*
 * @(#)SorteioUtils.java 1.00 29/04/2012 Copyright 2012 CPA Consulting LTDA.
 * Todos os direitos reservados. CPA PROPRIETARY/CONFIDENTIAL.
 * Proibida a c�pia e-ou a reprodu��o deste c�digo.
 */
package br.com.impacta.utils;

import java.util.Arrays;

/**
 * Contem metodos utilitarios para sorteio de numeros e outros valores aleatorios.
 * 
 * @author sandro.vieira
 * @version 1.0, 29/04/2012 - sandro.vieira - Implementacao.
 */
public class SorteioUtils {

    /**
     * Inibe a criacao de instancias desta classe.
     */
    private SorteioUtils() {
        // do nothing
    }
    
    /**
     * Simula o sorteio de cara/coroa a partir de uma moeda.
     * @return "<b><code>Cara</code></b>" ou "<b><code>Coroa</code></b>"
     */
    public static String sortearCaraCoroa() {
        int random = (int) (Math.random() * 2);
        if (random == 0) {
            return "Cara";
        } else {
            return "Coroa";
        }
    }

    /**
     * Simula o sorteio de um dado comum de 6 lados.
     * @return Um numero inteiro entre 1 e 6.
     */
    public static int sortearDado() {
        return (int) (Math.random() * 6) + 1;
    }

    /**
     * Simula o sorteio da Mega Sena.
     * @return Array contendo 6 dezenas aleatorias, ordenadas e nao repetidas entre 1 e 60.
     */
    public static int[] sortearMegasena() {
        int[] resultado = new int[6];
        int dezena = 0;
        for (int i = 0; i < resultado.length; i++) {
            do {
                dezena = (int) (Math.random() * 60) + 1;
            } while (search(resultado, dezena) > -1);
            resultado[i] = dezena;
        }
        Arrays.sort(resultado);
        return resultado;
    }

    /**
     * Metodo auxiliar que procura um numero inteiro dentro de um array.
     * 
     * @param array Array a ser pesquisado.
     * @param value Valor a ser procurado dentro do array.
     * 
     * @return Indice da posicao onde o valor foi encontrado. -1 quando nao e encontrado.
     */
    private static int search(int[] array, int value) {
        for (int index = 0; index < array.length; index++) {
            if (array[index] == value) {
                return index;
            }
        }
        return -1;
    }
}
